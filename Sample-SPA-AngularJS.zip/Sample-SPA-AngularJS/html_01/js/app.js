/*
* ------------------------------------------------------------------------
*
*   Custom AngularJS
*   Added by: John Ryan Acoba
*
* ------------------------------------------------------------------------
*/

angular.module('companyb', ['ui.bootstrap']);

var module = angular.module('companyb', ['ngRoute']);

module.directive('header', function() {
    return {
        restrict: 'A',
        replace: true,
        templateUrl: "templates/header.html",
        controller: ['$scope', '$filter', function($scope, $filter) {
            // behavior
        }]
    }
});

module.directive('footer', function() {
    return {
        restrict: 'A',
        replace: true,
        templateUrl: "templates/footer.html",
        controller: ['$scope', '$filter', function($scope, $filter) {
            // behavior
        }]
    }
});

module.directive('testimonials', function() {
    return {
        restrict: 'A',
        replace: true,
        templateUrl: "templates/testimonials.html",
        controller: ['$scope', '$filter', function($scope, $filter) {
            // behavior
        }]
    }
});


module.config(function($routeProvider) {
    $routeProvider

    .when('/main', {
        templateUrl: 'templates/main-page.html',
        controller: 'mainController'
    })

    .when('/about', {
        templateUrl: 'templates/about-page.html',
        controller: 'aboutController'
    })

    .when('/contact', {
        templateUrl: 'templates/contact-page.html',
        controller: 'contactController'
    })

    .when('/services', {
        templateUrl: 'templates/services-page.html',
        controller: 'serviceController'
    })

    .otherwise({
        redirectTo: '/main',
        templateUrl: 'templates/main-page.html',
        controller: 'mainController'
    });
});


module.controller('mainController', function($scope) {
    $scope.message = 'Welcome';
});

module.controller('aboutController', function($scope) {
    $scope.message = 'About Us';
});

module.controller('contactController', function($scope) {
    $scope.message = 'Contact Us';
});

module.controller('serviceController', function($scope) {
    $scope.message = 'Our Services';
});


module.controller('navbarController', ['$scope', '$location', function ($scope, $location) {
  $scope.isCollapsed = false;

    $scope.navLinks = [{
      Title: 'main',
      LinkText: 'Home',
    }, {
      Title: 'about',
      LinkText: 'About Us'
    }, {
      Title: 'contact',
      LinkText: 'Contact Us'
    }, {
      Title: 'services',
      LinkText: 'Services'
    }];

  $scope.navClass = function (page) {
    var currentRoute = $location.path().substring(1) || 'home';
    return page === currentRoute ? 'active' : '';
  };
}]);
