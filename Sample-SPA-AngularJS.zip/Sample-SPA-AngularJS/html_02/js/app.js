/*
* ------------------------------------------------------------------------
*
*   Custom AngularJS
*   Added by: John Ryan Acoba 
*
* ------------------------------------------------------------------------
*/

angular.module('create', ['ui.bootstrap']);

var module = angular.module('create', ['ngRoute']);

module.directive('header', function() {
    return {
        restrict: 'A',
        replace: true,
        templateUrl: "templates/header.html",
        controller: ['$scope', '$filter', function($scope, $filter) {
            // behavior
        }]
    }
});

module.directive('footer', function() {
    return {
        restrict: 'A',
        replace: true,
        templateUrl: "templates/footer.html",
        controller: ['$scope', '$filter', function($scope, $filter) {
            // behavior
        }]
    }
});


module.config(function($routeProvider) {
    $routeProvider

    .when('/main', {
        templateUrl: 'templates/main-page.html',
        controller: 'mainController'
    })

    .when('/pies', {
        templateUrl: 'templates/pies-page.html',
        controller: 'piesController'
    })

    .when('/cakes', {
        templateUrl: 'templates/cakes-page.html',
        controller: 'cakesController'
    })

    .otherwise({
        redirectTo: '/main',
        templateUrl: 'templates/main-page.html',
        controller: 'mainController'
    });
});


module.controller('mainController', function($scope) {
    $scope.message = 'Welcome';
});

module.controller('piesController', function($scope) {
    $scope.message = 'Pies';
});

module.controller('cakesController', function($scope) {
    $scope.message = 'Cakes';
});


module.controller('navbarController', ['$scope', '$location', function ($scope, $location) {
  $scope.isCollapsed = false;

    $scope.navLinks = [{
      Title: 'main',
      LinkText: 'Home',
    }, {
      Title: 'pies',
      LinkText: 'Pies'
    }, {
      Title: 'cakes',
      LinkText: 'Cakes'
    }];

  $scope.navClass = function (page) {
    var currentRoute = $location.path().substring(1) || 'home';
    return page === currentRoute ? 'active' : '';
  };
}]);











